Ali drawy 
211556493
URL cpanel : alidr.mysoft.jce.ac.il/ex1DisSystem.html
============ q5-1 ============

הלקוח מיציר הודעת HTTP request 
והשרת מיציר הודעת HTTP respons
והמנגנון HTTP

============ q5-2=============
בקשה ראשונה:
Request URL: https://wikimedia.org/api/rest_v1/metrics/pageviews/per-article/en.wikipedia/all-access/all-agents/Horned%20Puffin/daily/20220308/20220315
Request method: GET
status: 200 ok
content-length: 178
content-type: application/json; charset=utf-8
access-control-allow-origin: *

//////////
בקשה שנייה:
Request URL: https://wikimedia.org/api/rest_v1/metrics/pageviews/per-article/en.wikipedia/all-access/all-agents/Burmese%20Brown%20Mountain%20Tortoise/daily/20220308/20220315
Request Method: GET
Status Code: 404 
content-length: 473
content-type: application/problem+json
access-control-allow-origin: *

content-type ההבדל בין שתי הבקשות הוא 
content-type כי הבקשה השניה תחזיר את ה  
עם שגיאה

